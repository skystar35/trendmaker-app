# TrendMakerApp

Simple Expo client for TrendMaker backend.
